"use client"
import { useEffect, useState } from "react";
import styles from '@/app/styles/personnage.module.css';

export default function Page({ params }) {
    const [personnage, setPersonnage] = useState(undefined);

    useEffect(() => {
        async function fetchData() {
            const request = await fetch('https://finalspaceapi.com/api/v0/character/' + params.id);
            const data = await request.json();
            setPersonnage(data);
        };
        fetchData();
    }, []);

    return (
        <main>
            <h2>Informations sur le personnage</h2>
            {personnage && (
                <div className={styles.perso}>
                    <h3>{personnage.name}</h3>
                    <img src={personnage.img_url} alt={personnage.name} />
                    <span>Origine : {personnage.origin}</span>
                    <ul className={styles.listAbilities}>
                        <span>Abilitées :</span>
                        {personnage.abilities ? personnage.abilities.map((ability, index) => (
                            <li key={index}>{ability}</li>
                        )) : <li>Aucune</li>}
                    </ul>
                </div>
            )}
        </main>
    );
}