export default function Page() {
    return (
        <main>
            <h1>À propos</h1>
            <p>
                Ce site affiche les informations des personnages de la série Final Space.
            </p>
        </main>
    );
}