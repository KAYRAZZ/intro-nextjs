"use client"
import { useEffect, useState } from "react";
import Link from "next/link";
import styles from "./styles/accueil.module.css";

export default function Home() {
  const [personnages, setPersonnages] = useState(undefined);

  useEffect(() => {
    async function fetchData() {
      const request = await fetch('https://finalspaceapi.com/api/v0/character/');
      const data = await request.json();
      setPersonnages(data);
    };
    fetchData();
  }, []);


  {/* ----------- Etape 5 ----------- */ }
  const [limit, setLimit] = useState(undefined);

  async function handleLimitData() {
    const request = await fetch('https://finalspaceapi.com/api/v0/character/?limit=' + limit);
    const data = await request.json();
    setPersonnages(data);
  };
  {/* ------------------------------- */ }


  return (
    <main>
      <h2>Personnages de Final Space</h2>

      {/* ----------- Etape 5 ----------- */}
      <input type="text" value={limit} onChange={e => setLimit(e.target.value)} />
      <input type="button" value="Valider" onClick={handleLimitData} />
      {/* ------------------------------- */}

      <ul className={styles.listPerso}>
        {personnages && personnages.map((personnage) => (
          <li key={personnage.id} className={styles.perso}>
            <Link href={`/personnage/${personnage.id}`}>{personnage.name}</Link>
            <img src={personnage.img_url} alt={personnage.name} />
          </li>
        ))}
      </ul>
    </main>
  );
}
