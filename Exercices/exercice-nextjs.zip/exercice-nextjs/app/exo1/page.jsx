export default function Exo1() {
    // -------- Variable --------
    let article = 'Table';
    let fabrication = 'France';

    // -------- Return --------
    return ("");
}
